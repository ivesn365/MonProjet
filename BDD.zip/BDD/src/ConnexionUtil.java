import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class ConnexionUtil {
	
	public static Connection getConnection() throws SQLException{
		Connection conn = null;
		


