import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Fen2 extends JFrame {
	//On déclare notre objet JTextArea
	private JTextArea textPane = new JTextArea();
	//L'objet qui va gérer le scroll
	//En lui passant un objet JComponent dans le constructeur
	private JScrollPane scroll = new JScrollPane(textPane);
	//Vous êtes habitués à cette classe, maintenant... ;)
	public Fen2(){
		this.setLocationRelativeTo(null);
		this.setTitle("Gérer vos conteneur");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(200, 200);
		JButton bouton = new JButton("Bouton");
		bouton.addActionListener(new ActionListener(){
		public void actionPerformed (ActionEvent e){
		System.out.println("Texte écrit dans le JTextArea : ");
		System.out.println("--------------------------------");
		System.out.println(textPane.getText());
		}
		});
	
	//On ajoute l'objet au contentPane de notre fenêtre
	this.getContentPane().add(scroll, BorderLayout.CENTER);
	this.getContentPane().add(bouton, BorderLayout.SOUTH);
	this.setVisible(true);
	}
	public static void main(String[] args){
	Fen2 fen = new Fen2();
	}
}