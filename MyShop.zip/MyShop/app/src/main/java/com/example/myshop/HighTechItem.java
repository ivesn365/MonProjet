package com.example.myshop;

public class HighTechItem {
    // Les attributs
    private String name;
    private double price;

    // constuctor

    public HighTechItem(String name, double price){
        this.name = name;
        this.price = price;
    }

    // methods
    public String getName(){ return this.name; }

    public double getPrice(){ return this.price; }
}
