package com.example.myshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class HighTechItemAdapter  extends BaseAdapter {
    // fields
    private Context context;
    private List<HighTechItem> highTechItems;
    private LayoutInflater inflater;

    // constructor
    public HighTechItemAdapter(Context context, List<HighTechItem> highTechItems){
        this.context = context;
        this.highTechItems = highTechItems;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return highTechItems.size();
    }

    @Override
    public HighTechItem getItem(int position) {
        return highTechItems.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       view = inflater.inflate(R.layout.adapter_item, null);

       // get informations about item
       HighTechItem currentItem = getItem(i);
       String itemName = currentItem.getName();
       double itemPrice = currentItem.getPrice();
       // get item name view
        TextView itemNameView = view.findViewById(R.id.item_name);
        itemNameView.setText(itemName);

        // get item price view
        TextView itemPriceView = view.findViewById(R.id.item_price);
        itemPriceView.setText(itemPrice + "$");
        return view;
    }
}
