package com.example.myshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // list of items

        List<HighTechItem> highTechItems = new ArrayList<>();
        highTechItems.add(new HighTechItem("Ordinateur fixe", 1000));
        highTechItems.add(new HighTechItem("Processeur x2000", 2000));
        highTechItems.add(new HighTechItem("Super clavier", 50));

        //get list view

        ListView shopListView = findViewById(R.id.shop_list_vie);
        shopListView.setAdapter(new HighTechItemAdapter(this, highTechItems));
    }
}