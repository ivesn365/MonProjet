package TP2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class Publication extends Etudiant{
	private float pourcent;
	
	Publication(){}


	public Publication(float pourcent) {
		super();
		this.pourcent = pourcent;
	}
	


	public Publication(String nom, String postNom, String prenom, String matricule, String proomotion, float pourcent) {
		super(nom, postNom, prenom, matricule, proomotion);
		// TODO Auto-generated constructor stub
		this.pourcent = pourcent;
	}


	public float getPourcent() {
		return pourcent;
	}

	public void setPourcent(float pourcent) {
		this.pourcent = pourcent;
	}
	
	
	@Override
	public String toString() {
		return matricule + " " + getNom() + " " + getPostNom() + " " + getPrenom() +  " " + proomotion + " " + pourcent + "%" + '\n';
	}
	
}
	


