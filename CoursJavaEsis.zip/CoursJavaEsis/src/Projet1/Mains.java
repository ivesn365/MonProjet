package Projet1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import seance.Etudiant;





public class Mains {

	public static void main(String[] args) {
		Hashtable<Float,  String> hash = new Hashtable<Float, String>();
		hash.put((float) 8.5, "Bonjoour, 8");
		hash.put((float) 5.0, "Cool, 5");
		hash.put((float) 7.6, "tresor, 7");
		hash.put((float) 4.9, "d'accord, 4");
		hash.put((float) 1.1, "gentil, 1");
		hash.put((float) 3.8, "sage, 3");
		hash.put((float) 2.7, "grace, 2");
		hash.put((float) 6.4, "chance, 6");
		tri(hash);

	}
	
	static void tri(Hashtable<Float,  String> hash) {
		List keyList = new ArrayList(hash.keySet());
		List mesDonnees = new  ArrayList();
		Collections.sort(keyList, Collections.reverseOrder());
		Enumeration en = hash.elements();
		String et;
		for(Object i : keyList) {
			for(Map.Entry entry : hash.entrySet()) {
				if(i == entry.getKey()) mesDonnees.add(hash.get(i));
				}
		              
			
	       }
		for(Object j : mesDonnees) System.out.println(j);
		
      }

}
