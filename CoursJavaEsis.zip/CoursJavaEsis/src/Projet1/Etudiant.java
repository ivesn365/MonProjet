package Projet1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Etudiant extends Personne{
	private String matricule;
	private String proomotion;
	public Etudiant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Etudiant(String nom, String postNom, String prenom) {
		super(nom, postNom, prenom);
		// TODO Auto-generated constructor stub
	}
	public String getMatricule() {
		return matricule;
	}
	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}
	public String getProomotion() {
		return proomotion;
	}
	public void setProomotion(String proomotion) {
		this.proomotion = proomotion;
	}
	@Override
	public String toString() {
		return "matricule=" + matricule + ", nom=" + getNom() + ", postNom=" + getPostNom() + ", prenom=" + getPrenom() +", proomotion=" + proomotion + '\n';
	}

	public void serialised(List<Etudiant> p) {
		try {
			FileOutputStream fileOut = new FileOutputStream("etudiant.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(p);
			out.close();
			fileOut.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void deserialised() {
		String person;
		List mesArticles = new ArrayList();
		try {
			FileInputStream fileIn = new FileInputStream("etudiant.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			
			mesArticles.add((in.readObject()));
			in.close();
			fileIn.close();
		}catch(IOException i) {
			i.printStackTrace();
			return;
	
		
	   }catch(ClassNotFoundException e) {
		   
		   e.printStackTrace();
	   }
		
		for(Object str : mesArticles)System.out.println(str);
		
	}


}
