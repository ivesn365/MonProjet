package TP;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

public class Cotes extends Etudiant{
	private int moyenne;
	private int examen;
	
	Cotes(){}
	
	Cotes(String matricule, int examen, int moyenne, String promotion){
		this.examen = examen;
		this.moyenne = moyenne;
		this.matricule = matricule;
		this.proomotion = promotion;
	}
	
	public Cotes(String nom, String postNom, String prenom, String matricule, String proomotion) {
		super(nom, postNom, prenom, matricule, proomotion);
		// TODO Auto-generated constructor stub
	}



	public Cotes(String nom, String postNom, String prenom) {
		super(nom, postNom, prenom);
		// TODO Auto-generated constructor stub
	}



	public int getMoyenne() {
		return moyenne;
	}



	public void setMoyenne(int moyenne) {
		this.moyenne = moyenne;
	}



	public int getExamen() {
		return examen;
	}



	public void setExamen(int examen) {
		this.examen = examen;
	}
	
	public int moyenne() {
		return ((this.moyenne + this.examen)/100) * 100;
	}



	
	public void serialisCotes(List<Cotes> cotes) {
		
		try {
			FileOutputStream fileOut = new FileOutputStream("gestionCotes/cotes.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(cotes);
			out.close();
			fileOut.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList deserialiser() {
		Object et;
		ArrayList ets = new ArrayList();
		
	
		try {
			FileInputStream fileIn = new FileInputStream("gestionCotes/cotes.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			et = in.readObject();
			ets.add(et);
			
			in.close();
			fileIn.close();
		}catch(IOException i) {
			i.printStackTrace();
			
	
		
	   }catch(ClassNotFoundException e) {
		  
		   e.printStackTrace();
	   }
		return ets;
	
	}

	
	
	public void print() {
		for(Object et : deserialiser()) System.out.println(et);
	}
	
	
	public void publication(String pub) {
		File  monDossier = new File("gesionCotes");
		if(monDossier.isDirectory()) {
			monDossier.mkdir();
			
		}
		FileWriter monFichier;
		try {
			monFichier = new FileWriter("gesionCotes/publication.txt", true);
			//monFichier.createNewFile();
			PrintWriter p = new PrintWriter(monFichier);
			p.println(pub);
			p.flush();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
				
		
	}
	
	public void write(String cote) throws IOException {
		// TODO Auto-generated method stub
		File  monDossier = new File("gestionCotes");
		if(monDossier.isDirectory()) {
			monDossier.mkdir();
			
		}
		FileWriter monFichier = new FileWriter("gestionCotes/cotes.txt", true);
			
				//monFichier.createNewFile();
				PrintWriter p = new PrintWriter(monFichier);
				p.println(cote);
				p.flush();
		
	}
	
	public void print1() {
		System.out.println("===================================Resultat de la session=======================================");
		try {
			BufferedReader read = new BufferedReader(new FileReader("gesionCotes/publication.txt"));
			String ligne;
			while((ligne = read.readLine()) != null) {
				System.out.println(ligne);
				
			}
			read.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return matricule + " " + moyenne + " " + examen + '\n';
	}
	

}
