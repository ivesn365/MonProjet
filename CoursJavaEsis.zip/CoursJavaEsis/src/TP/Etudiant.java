package TP;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;



public class Etudiant extends Personne{
	/**
	 * 
	 */
	
	protected String matricule;
	protected String proomotion;
	
	Etudiant(){
		super();
	}
	
	public Etudiant(String nom, String postNom, String prenom) {
		super(nom, postNom, prenom);
		// TODO Auto-generated constructor stub
	}

	public Etudiant(String nom, String postNom, String prenom, String matricule, String proomotion) {
		super(nom, postNom, prenom);
		this.matricule = matricule;
		this.proomotion = proomotion;
	}
	
	public String getMatricule() {
		return matricule;
	}
	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}
	public String getProomotion() {
		return proomotion;
	}
	public void setProomotion(String proomotion) {
		this.proomotion = proomotion;
	}
	
	public void write(String etudiant) throws IOException {
		// TODO Auto-generated method stub
		File  monDossier = new File("gestionCotes");
		if(monDossier.isDirectory()) {
			monDossier.mkdir();
			
		}
		FileWriter monFichier = new FileWriter("gestionCotes/etudiants.txt", true);
			
				//monFichier.createNewFile();
				PrintWriter p = new PrintWriter(monFichier);
				p.println(etudiant);
				p.flush();
		
	}
	
	public void read() {
		// TODO Auto-generated method stub
		
	}
	
	
	public void serialiser(List<Etudiant> et) {
	
		try {
			FileOutputStream fileOut = new FileOutputStream("gestionCotes/etudiants.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(et);
			out.close();
			fileOut.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList deserialiser() {
		Object et;
		ArrayList ets = new ArrayList();
		
	
		try {
			FileInputStream fileIn = new FileInputStream("gestionCotes/etudiants.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			et = in.readObject();
			ets.add(et);
			
			in.close();
			fileIn.close();
		}catch(IOException i) {
			i.printStackTrace();
			
	
		
	   }catch(ClassNotFoundException e) {
		  
		   e.printStackTrace();
	   }
		return ets;
	
	}

	@Override
	public String toString() {
		return matricule + " " + getNom() + " " + getPostNom() + " " + getPrenom() +  " " + proomotion + '\n';
	}
	
	public void print() {
		for(Object et : deserialiser()) System.out.println(et);
	}
	
	public void fichierXml(String nom, String postNom, String prenom, String matricule, String promotion, float pourcent, int id) {
		DocumentBuilderFactory db = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder docB = db.newDocumentBuilder();
			Document doc = docB.newDocument();
			// element racine
			Element racine = doc.createElement("repertoire");
			doc.appendChild(racine);
			// element contact
			Element etudiant = doc.createElement("etudiant");
			racine.appendChild(etudiant);
			
			//attribut de l'element contact
			Attr attr = doc.createAttribute("id");
			attr.setValue(""+id+"");
			etudiant.setAttributeNode(attr);
			
			// le nom 
			Element nom1 = doc.createElement("nom");
			nom1.appendChild(doc.createTextNode(""+nom+""));
			racine.appendChild(nom1);
			
			Element pnom = doc.createElement("postnom");
			pnom.appendChild(doc.createTextNode(""+postNom+""));
			racine.appendChild(pnom);

			// le prenom
			
			Element prenom1 = doc.createElement("prenom");
			prenom1.appendChild(doc.createTextNode(""+prenom+""));
			racine.appendChild(prenom1);
			
			
			Element mat = doc.createElement("matricule");
			mat.appendChild(doc.createTextNode(""+matricule+""));
			racine.appendChild(mat);
			
			Element pro = doc.createElement("promotion");
			pro.appendChild(doc.createTextNode(""+promotion+""));
			racine.appendChild(pro);
			
			Element pourcent1 = doc.createElement("pourcentage");
			pourcent1.appendChild(doc.createTextNode(""+pourcent+""));
			racine.appendChild(pourcent1);
			
			TransformerFactory transforme = TransformerFactory.newInstance();
			Transformer tr;
			try {
				tr = transforme.newTransformer();
			
			DOMSource source = new DOMSource(doc);
			StreamResult re;
			
				re = new StreamResult(new FileWriter("gestionCotes/etudiant.xml", true));
			
			
				tr.transform(source, re);
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
