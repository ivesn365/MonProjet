package notionDeClass;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personne p = new Personne("Congolaise", 25);
		p.parler();
		Enfant e =  new Enfant("Congolaise", 25);
		e.parler();
		System.out.println(e.pere());

	}

}
