package notionDeClass;

public class Enfant extends Personne implements Parent{

	public Enfant(String nationalite, int aNaiss) {
		super(nationalite, aNaiss);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void parler() {
		System.out.println("l'enfant pleure mdr ! ! ! !");
	}

	@Override
	public String pere() {
		// TODO Auto-generated method stub
		return "Tu as aussi un père mdr ! ! !";
	}

	@Override
	public String mere() {
		// TODO Auto-generated method stub
		return "Et aussi une mère mdr ! ! !";
	}

}
