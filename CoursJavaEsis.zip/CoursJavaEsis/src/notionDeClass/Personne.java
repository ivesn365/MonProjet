package notionDeClass;

public class Personne {
	public String nationalite;
	int aNaiss;
	String adress;
	public Personne(String nationalite, int aNaiss) {
		super();
		this.nationalite = nationalite;
		this.aNaiss = aNaiss;
	}
	
	public String getNationalite() {
		return nationalite;
	}
	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}
	public int getaNaiss() {
		return aNaiss;
	}
	public void setaNaiss(int aNaiss) {
		this.aNaiss = aNaiss;
	}
	
	public void setAdress(String adress) {
		this.adress = adress;
	}
	
	public String getAdress() {
		return this.adress;
	}
	
	public void parler() {
		System.out.println("parle  mdr! ! ! ");
	}

}
