package notionDeClass;

public interface Parent {
	public String pere();
	public String mere();

}
