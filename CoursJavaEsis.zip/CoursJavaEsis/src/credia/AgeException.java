package credia;

public class AgeException extends Exception{
	AgeException(){
		super("Désolé il faut juste avoir un minumum de 18 ans");
	}

}
