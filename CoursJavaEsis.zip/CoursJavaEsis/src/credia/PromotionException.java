package credia;

public class PromotionException extends Exception{
	
	PromotionException() {
		super("Désolé on engage juste les étudiant de L3GL");
	}

}
