package credia;

public class Stagiaire implements StagiaireInterface{
	private String nom;
	private String prenom;
	private String ecole;
	private String promotion;
	private int age;
	
	public Stagiaire() {}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getEcole() {
		return ecole;
	}
	public void setEcole(String ecole) throws EcoleException {
		if(ecole == "esis")this.ecole = ecole;
		else throw new EcoleException();
	}
	public String getPromotion() {
		return promotion;
	}
	public void setPromotion(String promotion) throws PromotionException {
		if(!promotion.equals("l3gl") ) {throw new PromotionException();}
		else {this.promotion = promotion;}
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) throws AgeException {
		if(age < 18 ) {throw new AgeException();}
		else {this.age = age;}
	}
	@Override
	public String coder(String langage) {
		// TODO Auto-generated method stub
		return "Je suis un développeur en " + langage;
		
	}
	
	

}
