package credia;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws EcoleException, AgeException, PromotionException {
		Scanner sc = new Scanner(System.in);
		Stagiaire s1 = new Stagiaire();
		String str;
		String tab = "";
		int j;
		System.out.println("=========================================================================================");
		System.out.println("Bienvenue chez nous ! ! !");
		System.out.println("=========================================================================================");
		System.out.print("Veuillez taper notre nom : ");
		str = sc.nextLine();
		s1.setNom(str);
		tab += s1.getNom() + " ";
		System.out.print("Veuillez taper notre prénom : ");
		str = sc.nextLine();
		s1.setPrenom(str);
		tab += s1.getPrenom() + " ";
		
		
		System.out.print("Veuillez taper notre promotion: ");
		str = sc.nextLine();
		s1.setPromotion(str);
		tab += s1.getPromotion();
		System.out.print("Veuillez taper notre âge : ");
		j = sc.nextInt();
		s1.setAge(j);
		tab += s1.getAge() + " ";
		System.out.print("Veuillez taper notre langage de programmation : ");
		str = sc.nextLine();
		tab += s1.coder(str);
		System.out.println();
		System.out.println(tab);
		
		
		
		

	}

}
