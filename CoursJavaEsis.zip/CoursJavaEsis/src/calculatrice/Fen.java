package calculatrice;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Fen extends JFrame implements ActionListener{
	
	 JButton reset = new JButton("CE"); 
     JButton b7 = new JButton("7");
     JButton b8 = new JButton("8");
     JButton b9 = new JButton("9");
     JButton _bdiv = new JButton("/");
     JButton b4 = new JButton("4");
     JButton b5 = new JButton("5");
     JButton b6 = new JButton("6");
     JButton _bm = new JButton("X");
     JButton b3 = new JButton("3");
     JButton b2 = new JButton("2");
     JButton b1 = new JButton("1");
     JButton _b = new JButton("-");
     JButton _bv = new JButton(".");
     JButton b0 = new JButton("0");
     JButton _beg = new JButton("=");
     JButton _bplus = new JButton("+");
     JButton histo = new JButton("Histori");
     String myHistoric = "";
     
     JLabel historicLabel = new JLabel();
     
     JTextField display = new JTextField();
	
	 Fen(){
		// Fenetre
				JFrame fen=new JFrame("Calculatrice");
		        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        fen.setLocationRelativeTo(null);
		       
		       
		        JPanel pnlHeadHisto = new JPanel(new BorderLayout());
		        pnlHeadHisto.add(histo);
		        JPanel pnlHead = new JPanel(new BorderLayout());
		        pnlHead.add(pnlHeadHisto, BorderLayout.NORTH);
		        pnlHead.add( display, BorderLayout.CENTER);
		        pnlHead.add( reset, BorderLayout.EAST);
		        
		        JPanel panPrincipale = new JPanel();
		        GridLayout layP = new GridLayout(0, 4);
		        panPrincipale.setLayout(layP);
		        JPanel historic = new JPanel(new BorderLayout());
		        
		        
		        JPanel conteneur = new JPanel(new BorderLayout());
		        
		      
		        
		       

		        
		        panPrincipale.add(b7);
		        panPrincipale.add(b8);
		        panPrincipale.add(b9);
		        panPrincipale.add(_bdiv);
		        panPrincipale.add(b4);
		        panPrincipale.add(b5);
		        panPrincipale.add(b6);
		        panPrincipale.add(_bm);
		        panPrincipale.add(b1);
		        panPrincipale.add(b2);
		        panPrincipale.add(b3);
		        panPrincipale.add(_b);
		        panPrincipale.add(_bv);
		        panPrincipale.add(b0);
		        panPrincipale.add(_beg);
		        panPrincipale.add(_bplus);
		        
		          
		        
		        
		        
		        
		        conteneur.add(BorderLayout.NORTH, pnlHead);
		        conteneur.add(BorderLayout.CENTER, panPrincipale);
		        
		        reset.addActionListener(this);
		        b0.addActionListener(this);
		        b1.addActionListener(this);
		        b2.addActionListener(this);
		        b3.addActionListener(this);
		        b4.addActionListener(this);
		        b5.addActionListener(this);
		        b6.addActionListener(this);
		        b7.addActionListener(this);
		        b8.addActionListener(this);
		        b9.addActionListener(this);
		        _b.addActionListener(this);
		        _bdiv.addActionListener(this);
		        _beg.addActionListener(this);
		        _bm.addActionListener(this);
		        _bplus.addActionListener(this);
		        _bv.addActionListener(this);
		        
		        histo.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						//conteneur.add(historic, 0);
						/*panPrincipale.setVisible(false);
						pnlHead.setVisible(true);
						conteneur.remove(panPrincipale);*/
						write(myHistoric);
						
						JOptionPane jop1;
						jop1 = new JOptionPane();
						int option = jop1.showConfirmDialog(null, historic.add(new JTextArea(readFile())),
						"Historique", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
						
						if(option == JOptionPane.YES_OPTION) viderFile();
						
					}
				
				});
		        
		        
		      
		       
		        fen.setContentPane(conteneur);
		       
		        
		        //fen.pack();
		        fen.setSize(300, 280);
		        fen.setVisible(true);

		
	}

	
	
	 public void actionPerformed(ActionEvent e) {
	        Object source = e.getSource();
	        String cmd = e.getActionCommand();
	        if (source == reset)
	            sReset();
	        else if ("0123456789.".indexOf(cmd) >= 0) {
	        	myHistoric += cmd + " ";
	        	nbre(cmd);
	        	
	        }
	        else{
	        	myHistoric += cmd + " ";
	        	CalculOperator(cmd);
	        }
	        
	    }

	    boolean premierChiffre = true;
	    double number = 0.0;
	    String operator = "=";
	    
	    
		
	    public void nbre(String key) {
	        if (premierChiffre)
	            display.setText(key);
	        else if (!key.equals("."))
	            display.setText(display.getText() + key);
	        else if (display.getText().indexOf(".") < 0)
	            display.setText(display.getText() + ".");
	        premierChiffre = false;
	        
	    }

	    public void sReset() {
	        display.setText("0");
	        premierChiffre = true;
	        operator = "=";
	    }
	    
	    public void CalculOperator(String cmd) {
			double dDisplay = Double.valueOf(display.getText());
			switch(operator){
				case "+": number += dDisplay;this.myHistoric += number + " " + '\n'; break;
				case "-": number -= dDisplay;this.myHistoric += number + " " + '\n';  break;
				case "X": number *= dDisplay;this.myHistoric += number + " " + '\n'; break;
				case "/": number /= dDisplay;this.myHistoric += number + " " + '\n';  break;
				case "=": number = dDisplay; this.myHistoric += number + " " + '\n'; break;
			}
			display.setText(String.valueOf(number));
	        operator = cmd;
	        //this.myHistoric += cmd;
	        premierChiffre = true;
	    }
	    
		public String readFile() {
			String mHistoric = "";
	    	try {
				BufferedReader read = new BufferedReader(new FileReader("historic.txt"));
				String ligne;
				
				while((ligne = read.readLine()) != null) {
					
					mHistoric += ligne + '\n';
				}
				
				read.close();
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	return mHistoric;
	    }
	    
		public void write(String myH){
			// TODO Auto-generated method stub
			
			FileWriter monFichier;
			try {
				monFichier = new FileWriter("historic.txt", true);
				PrintWriter p = new PrintWriter(monFichier);
				p.println(myH);
				p.flush();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			public void viderFile(){
				// TODO Auto-generated method stub
				
				FileWriter monFichier;
				try {
					monFichier = new FileWriter("historic.txt");
					PrintWriter p = new PrintWriter(monFichier);
					p.println("");
					p.flush();
				}catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
					
			
		}
	    

	 
	 public static void main(String[] args) {
		 Fen f = new Fen();
			
		}

}
