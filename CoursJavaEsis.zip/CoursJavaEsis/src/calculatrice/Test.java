package calculatrice;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Test {
	

	public static void main(String[] args) {

        // INTERFACE GRAPHIQUE
        JFrame fen=new JFrame("Enregistrement des etudiants");
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setLocationRelativeTo(null);
        
        JPanel fond = new JPanel(new BorderLayout());
        GridLayout gd2 = new GridLayout(2,2);
        fond.setLayout(gd2);
        
        //PANE OPTION
        GridLayout layP=new GridLayout(0, 2);
        
        
        JButton btnAnnuler=new JButton("Annuler");
        JButton btnCalculer=new JButton("Enregistrer");
        
        JLabel lblMatricule=new JLabel("Matricule");
        JTextField txtMatricule=new JTextField();
        JLabel lblNom=new JLabel("Nom complet");
        JTextField txtNom=new JTextField();
        JLabel lblPromotion=new JLabel("Promotion");
        JTextField txtPromotion=new JTextField();
        JPanel panPrincipale=new JPanel();
        panPrincipale.setLayout(layP);
        panPrincipale.add(lblMatricule);
        panPrincipale.add(txtMatricule);
        panPrincipale.add(lblNom);
        panPrincipale.add(txtNom);
        panPrincipale.add(lblPromotion);
        panPrincipale.add(txtPromotion);
        //_________________Ajouter cours______________
        JLabel lblrefEtudiant = new JLabel("Matricule");
        JTextField txtFieldMatricule = new JTextField();
        JLabel lblCours = new JLabel("Cours");
        JTextField txtFieldNomCours = new JTextField();
        JLabel lblCoteMoyenne = new JLabel("Cote moyenne");
        JTextField txtFieldCoteMoyenne = new JTextField();
        JLabel lblCoteExamen = new JLabel("Cote examen");
        JTextField txtFieldCoteExamen = new JTextField();
        JButton annulerAjoutCours = new JButton("Annuler");
        JButton validerCoursCote = new JButton("Sauvegarder");
        JPanel panAjouterCours = new JPanel();
        panAjouterCours.setLayout(layP);
        panAjouterCours.add(lblrefEtudiant);
        panAjouterCours.add(txtFieldMatricule);
        panAjouterCours.add(lblCours);
        panAjouterCours.add(txtFieldNomCours);
        panAjouterCours.add(lblCoteMoyenne);
        panAjouterCours.add(txtFieldCoteMoyenne);
        panAjouterCours.add(lblCoteExamen);
        panAjouterCours.add(txtFieldCoteExamen);
        JPanel panButtons = new JPanel();
        panButtons.add(annulerAjoutCours);
        panButtons.add(validerCoursCote);
        panAjouterCours.add(panButtons);
        
        //________________Resultat a afficher_______
       
        Container contAfficheRes = Box.createVerticalBox();
        JButton retour = new JButton("Retour");
        JButton validerAffichage = new JButton("Valider");
        JPanel panButtonAffiche = new JPanel();
        panButtonAffiche.add(retour);
        panButtonAffiche.add(validerAffichage);        
        
        JPanel p2=new JPanel();
        p2.add(btnAnnuler);
        p2.add(btnCalculer);
        
        panPrincipale.add(new JLabel());
        panPrincipale.add(p2);
        panPrincipale.setVisible(false);
        
        JMenuBar barMenu=new JMenuBar();
        JMenu menuFichier=new JMenu("Fichier");
        JMenu menuEdition=new JMenu("Edition");
        
        JMenuItem it1=new JMenuItem("Ajouter etudiant");
        JMenuItem it2=new JMenuItem("Ajouter cours");
        JMenuItem it3=new JMenuItem("Afficher resultats");
        menuFichier.add(it1);
        menuFichier.add(it2);
        menuFichier.add(it3);
        
        //LES EVENEMENTS
        it1.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                //System.out.println("Bonjour le monde !");
                fond.add(panPrincipale, BorderLayout.NORTH);
                panPrincipale.setVisible(true);
            }
            
        });
        it2.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                //System.out.println("Bonjour le monde !");
                fond.add(panAjouterCours,0);
                panAjouterCours.setVisible(true);
            }
            
        });
        it3.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                //System.out.println("Bonjour le monde !");
                contAfficheRes.add(contAfficheRes, "12");
                contAfficheRes.add(panButtonAffiche);
                fond.add(contAfficheRes, "cool");
                contAfficheRes.setVisible(true);
            }
            
        });
        btnCalculer.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                panPrincipale.setVisible(false); 
                fond.remove(panPrincipale); 
            }
            
        });
        btnAnnuler.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("Bonjour ");
                panPrincipale.setVisible(false); 
                fond.remove(panPrincipale);      
            }
            
        });
        validerCoursCote.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                panAjouterCours.setVisible(false);
                fond.removeAll();
            }
            
        });
        annulerAjoutCours.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                panAjouterCours.setVisible(false);
                fond.removeAll();
            }
            
        });
        retour.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                contAfficheRes.setVisible(false);
//                contAfficheRes.removeAll();
                fond.removeAll();
            }
            
        });
        validerAffichage.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                contAfficheRes.setVisible(false);
//                contAfficheRes.removeAll();
                fond.removeAll();
            }
            
        });
        
        barMenu.add(menuFichier);
        barMenu.add(menuEdition);
        
        fen.setContentPane(fond);
        fen.setJMenuBar(barMenu);
        fen.setSize(700, 500);
//        fen.pack();
        fen.setVisible(true);

	}

}
