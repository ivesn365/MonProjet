package calculatrice;

import javax.swing.JOptionPane;

public class MonDialog {

	public static void main(String[] args) {
		JOptionPane jop1;
		jop1 = new JOptionPane();
		jop1.showConfirmDialog(null, "Message informatif",
		"Information", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
		
		
		
		}

}
