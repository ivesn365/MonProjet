package seance;

import java.awt.Color;



import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GridLayoutFen {

	public static void main(String[] args) {
		JFrame fen=new JFrame("Converter");
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setLocationRelativeTo(null);
        
        JLabel lblMontant=new JLabel("Montant");
        JLabel lblRes=new JLabel();
        lblRes.setText("Resultat");
        lblRes.setForeground(Color.red);
        JTextField txtMontant=new JTextField();
        JTextField txtResultat=new JTextField();
        txtResultat.setEditable(false);
        
        JButton btnAnnuler=new JButton("Annuler");
        JButton btnCalculer=new JButton("Calculer");
        
        JPanel panPrincipale=new JPanel();
        GridLayout layP=new GridLayout(0, 2);
        panPrincipale.setLayout(layP);
        panPrincipale.add(lblMontant);
        panPrincipale.add(txtMontant);
        panPrincipale.add(lblRes);
        panPrincipale.add(txtResultat);
        
        JPanel p2=new JPanel();
        p2.add(btnAnnuler);
        p2.add(btnCalculer);
        
        panPrincipale.add(new JLabel());
        panPrincipale.add(p2);
        
        JMenuBar barMenu=new JMenuBar();
        JMenu menuFichier=new JMenu("Fichier");
        JMenu menuEdition=new JMenu("Edition");
        
        JCheckBoxMenuItem it1 = new JCheckBoxMenuItem("CDF->USD");
        it1.setMnemonic(KeyEvent.VK_C);
        JCheckBoxMenuItem it2 = new JCheckBoxMenuItem("USD->CDF");
        it2.setMnemonic(KeyEvent.VK_C);
        it1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if(it1.isSelected()) {
					it2.setSelected(false);
					it1.setSelected(true);
				}
				
			}
		});
        
 it2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if(it2.isSelected()) {
					it1.setSelected(false);
					it2.setSelected(true);
				}
				
			}
		});
        menuFichier.add(it1);
        menuFichier.add(it2);
        
        barMenu.add(menuFichier);
        barMenu.add(menuEdition);
        
        btnCalculer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				AbstractButton btn = (AbstractButton)e.getSource();
				boolean t2 = it2.getModel().isSelected();
				
				boolean t1 = it1.getModel().isSelected();
				String calcul = "";
				float montant = Float.valueOf(txtMontant.getText());
				if(t1 != false) {
					calcul += montant / 2000 + "$";
				}
				else if(t2 != false) {
					calcul += montant * 2000 + "fc";
				}
				else if((t2 != false) && (t1 != false))calcul = "Impossible de convertir";
				else calcul += "Aucune device n'est selectionnée";
				txtResultat.setText(calcul);
				
				
			}
		});
        
        fen.setContentPane(panPrincipale);
        fen.setJMenuBar(barMenu);
       // fen.setSize(400, 200);
       fen.pack();
        fen.setVisible(true);	
        
	}
	
	public static void annuler() {
		
	}
	

}
