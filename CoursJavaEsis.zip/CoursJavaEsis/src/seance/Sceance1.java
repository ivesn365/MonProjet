package seance;

public class Sceance1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, b, c;
		a = 5;
		b = 12;
		c = 4;
		/*System.out.println((a + b - 2)  * c);
		double k = 13.2;
		System.out.println(k);
		k = b;
		System.out.println(k);
		k = (double)b;
		System.out.println(k);
		int r = 2;
		r += b;
		System.out.println(++r);
		System.out.println(--r);
		System.out.println(Math.pow(5, 2));
		*/
		//pgcd(9, 6);
		//suiteF(3);
		etoile(5);
		//etoile3();
		

	}
	public static void pgcd(int a, int b) {
		int r;
		if(a > 0 && b > 0) {
			if(a > b) {
				do {
					r = a%b;
					if(r == 0) {
						System.out.println("PGCD trouvé");
						break;
					}
					a = b;
					b = r;
					
				}while(r != 0);
			}
			
		} else System.out.println("Les entiers doivent être non null ! ! !");
	}
	
	public static void suiteF(int f) {
		for (int i = 0;i < f; i++) {
			
			if(2 > i)System.out.println(i);
			else {
				i = (i - 1) + (i -2);
				System.out.println(i);
			}
		}
	}
	
	static void etoile(int l) {

		for(int i = 1; i <= l; i++) {
			if (i == 1) System.out.print("*");
			else if(i == 2) {
				for(int j = 0; j < i; j++) System.out.print("|");
			}
				else if(i == 3)
					{
					for(int j = 0; j < 2; j++)  System.out.print("*");
					}
				else if(i == 4) {
					
				}
				else if (i == 4)for(int j = 0; j < 3; j++) System.out.print("*");
			System.out.print("\n");
			}
			
		}
	
	static void etoile2() {
		for(int i = 0; i <= 5; i++) {
			 
				if(i == 0)System.out.print("*");
				else if(i == 1) {
					for(int j = 0; j<= 2; j++) System.out.print("*");
				}
				else if(i == 2) {
					for(int j = 0; j<= 5; j++) System.out.print("*");
				}
			
			System.out.print("\n");
		}
	}
	
	static void etoile3() {
		for(int i = 0; i <= 5; i++) {

			if(i == 0) System.out.print("*");
			if(i == 1) {
				for(int j = 1; j<= 3; j++) System.out.print("*");
			}
			if(i == 2) {
				for(int j = 1; j<= 5; j++) System.out.print("*");
			}
			if(i == 3) {
				for(int j = 1; j<= 3; j++) System.out.print("*");
			}
			if(i == 4) System.out.print("*");
			
			System.out.print("\n");
			
			}
			
		}
	}


