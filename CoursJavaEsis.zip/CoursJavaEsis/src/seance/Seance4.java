package seance;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class Seance4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String l = "";
		
		File monDossier = new File("Dossier");
		if(!monDossier.isDirectory()) {
			monDossier.mkdir();
		}
		//monDossier.delete();
		File monFichier = new File("src/test1.txt");
			if(!monFichier.exists()) {
				try {
					monFichier.createNewFile();
					PrintWriter p = new PrintWriter(monFichier);
					p.println("John Doe");
					p.flush();
				} catch(IOException e) {
					
				}
				
			}else {
				monFichier.renameTo(new File(monDossier, "test.txt"));
			}
		

	}

}
