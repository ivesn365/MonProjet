package seance;

import java.util.Enumeration;
import java.util.Hashtable;

public class Hashtabletest {

	public static void main(String[] args) {
		Hashtable<String, Etudiant> ets = new Hashtable<String, Etudiant>();
		ets.put("17nn365", new Etudiant("Congolaise", 1999));
		//ets.put("16kl365", new Etudiant("16kl365", "L2GL", "ESIS", "Congolaise", 1997));
		
		ets.get("17nn365").setEcole("ESIS");
		ets.get("17nn365").setPromotion("L2MSI");
		ets.get("17nn365").setMatricule("17nn365");
		
		Enumeration<Etudiant> en = ets.elements();
		Etudiant et;
		while(en.hasMoreElements()) {
			et = en.nextElement();
			System.out.println(et.getMatricule() + " " + et.getaNaiss() + " " + et.getNationalite() + " " + et.getAdress() + " " + et.getEcole());
		}
		
		Enumeration<String> enK = ets.keys();
		String cles;
		
		while(enK.hasMoreElements()) {
			cles = enK.nextElement();
			System.out.println(cles);
		}

	}

}
