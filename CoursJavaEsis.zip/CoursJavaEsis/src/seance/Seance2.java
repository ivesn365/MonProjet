package seance;

public class Seance2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] tab = {4, 8, 5, 3, 0, 6, 15};
		//triBulles(tab);
		//nombPremier(tab);
		trans("611");

	}
	
	public static void triBulles(int[] tab) {
		int tmp;
		for(int i = 0;i < tab.length;i++) {
			for(int j = 0;j < tab.length-1; j++) {
				if(tab[j+1] < tab[j]) {
					tmp = tab[j];
					tab[j] = tab[j+1];
					tab[j+1] = tmp;
				}
			}
		}
		for(int k : tab) System.out.print(k + "\t");
	}
	
	public static void nombPremier(int tab[]) {
		int tmp;
		for(int i = 0; i < tab.length; i++) {
			if(tab[i] % 2 == 0)System.out.println(tab[i]);
		}
		
		
	}
	
	public static void trans(String nb) {
		String tab3 = "";
		String [] tab =  {"0","1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "30", "40", "50", "60", "70", "80", "90", "100"};
		String[] tab2 =	{"zero","un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf", "vingt", "trente", "quarante", "cinquante", "sosante", "septante", "quatre-vingt", "nonante", "cent"};
		if(nb.length() == 2) {
		for(int i = 0; i < nb.length(); i++) {
			if(i == 0){
			
			for(int j=0; j < tab.length; j++) {
				
				
					int n1 = Integer.parseInt(tab[j]);
					int n2 = Integer.parseInt(nb);
					int n4 = Integer.parseInt(nb.substring(0, 1));
					int n3 = Integer.parseInt(nb.substring(1, 2));
					if(((n1 == n2) && (n3 == 0)) || ((n1 == n2) && (n3 != 0))) {
						tab3 += tab2[j];
						break;
					}
				
					else if((n1 == n4 * 10) && (n3 != 0)) {
						tab3 += tab2[j];
						break;
					}
				}
					
				} else {
					for(int j=0; j < tab.length; j++) {
					int n1 = Integer.parseInt(tab[j]);
					int n2 = Integer.parseInt(nb.substring(1, 2));
					int n3 = Integer.parseInt(nb.substring(1, 2));
					if((n1 == n2) && (n2 != 0))tab3 += tab2[j];
					
				}
			}
				
				
			
			
			
			
			
		}
		
		}  if(nb.length() == 3) {
			int j = 0;
			
		    while(j < nb.length()) {
				for(int i = 0; i < tab.length; i++) {
					if(j == 0) {
						String mots = nb.substring(0, 1);
						int n1 = Integer.parseInt(tab[i]);
						int n2 = Integer.parseInt(nb.substring(0, 1));
						
						if(n1 == n2) {
							tab3 += tab2[i] + " cent";
							break;
							
						}
						
					}
					else if(j == 1){
						int n1 = Integer.parseInt(tab[i]);
						int n2 = Integer.parseInt(nb.substring(1, 2));
						if((n1 == n2*10) && (n2 != 0)) tab3 += " " + tab2[i];
					
						
					}
					else {
							int n1 = Integer.parseInt(tab[i]);
							int n2 = Integer.parseInt(nb.substring(2, 3));
							if(n2 != 0) {
								if(n1 == n2) tab3 += " " + tab2[i];
						}
						
						
						
					}
						
					
				}
				j++;
		    }
		}
		System.out.print(tab3);
	}

}
