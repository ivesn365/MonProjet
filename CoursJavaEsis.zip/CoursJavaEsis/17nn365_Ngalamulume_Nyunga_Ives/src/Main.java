package TP;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import notionDeClass.Personne;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Etudiant et = new Etudiant();
		Cotes c = new Cotes(null, null, null, null, null);
		Publication pub = new Publication();
		
		Scanner sc = new Scanner(System.in);
		int com = 0;
		List<Etudiant> ets = new ArrayList<>();
		List<Cotes> cotes = new ArrayList<>();
		Hashtable<Float, Publication> resultat = new Hashtable<>();
		
		float k, cle;
		
		
		do {
			k = 0;
			cle = 0;
			System.out.println("taper le nom");
			et.setNom(sc.nextLine());
			String nom = et.getNom();
			System.out.println("taper le postnom");
			et.setPostNom(sc.nextLine());
			String postnom = et.getPostNom();
			//pub += et.getNom() + " ";
			System.out.println("taper le prenom");
			et.setPrenom(sc.nextLine());
			String prenom = et.getPrenom();
			System.out.println("taper le maricule");
			et.setMatricule(sc.nextLine());
			String matricule = et.getMatricule();
			//pub += et.getMatricule() + " ";
			String coteM = c.getMatricule();
			System.out.println("taper la promotion");
			et.setProomotion(sc.nextLine());
			
			String pro = et.getProomotion();
			ets.add(new Etudiant(nom, postnom, prenom, matricule, pro));
			for(int i = 1; i <= 3; i++) {
				System.out.println("taper la moyenne");
				c.setMoyenne(sc.nextInt());
				int c1 =  c.getMoyenne();
				k += c.getMoyenne();
				
				System.out.println("taper les cotes examens ");
				c.setExamen(sc.nextInt());
				int ex =  c.getExamen();
				k += c.getExamen();
				
						
				cotes.add(new Cotes(matricule, c1, ex, pro));
				
			}
				k =  (k/60) * 100;
				cle = k + random();
				resultat.put(cle,new Publication(nom, postnom, prenom, matricule, pro, k));
						
			
			
				System.out.println("voulez-vous continuer? 0/1 ");
				com = sc.nextInt();
				sc.nextLine();
			
		} while(com != 0);
		
		et.serialiser(ets);
		c.serialisCotes(cotes);
		pub.tri(resultat);
		System.out.println("=========================================liste des étudiants pour la promotion:  "+ et.getProomotion() +"======================================================");
		et.print();
		/*System.out.println("=========================================liste des cotes  pour la promotion: "+ et.getProomotion() +"======================================================");
		c.print();*/
		System.out.println("=========================================Publication de Resultat pour la promotion:  "+ et.getProomotion() +"======================================================");
		pub.print();
		
		Iterator<Etudiant> it = ets.iterator();
		Etudiant p1;
		int i = 1;
		while(it.hasNext()) {
			p1 = it.next();
			et.fichierXml(p1.getNom(), p1.getPostNom(), p1.getPrenom(), p1.getMatricule(), p1.getProomotion(), i++);
		}
		
		
		

	}
	
	public static float random() {
		float nbre = (float) (Math.random() * 0.003);
		return nbre;
	}

}
