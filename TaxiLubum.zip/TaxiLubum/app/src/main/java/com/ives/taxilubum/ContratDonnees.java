package com.ives.taxilubum;

public class ContratDonnees {
    public static  final int SYNCHRO_REUSSIR = 0;
    public static final int SYNCHRO_ECHEC = 1;

    public static final String LIEN_URL = "http://192.168.42.91:8080/taxilubum/fonction/inscription.class.php";

    public static final String BDD = "taxilubum";
    public static final String NOMT = "chauffeur";
    public static final String NOMCHAUFFEUR = "nom";
    public static  final String TELEPHONECHAUFFEUR = "telephone";
    public static final String PHOTOCHAUFFEUR = "photo";

}
