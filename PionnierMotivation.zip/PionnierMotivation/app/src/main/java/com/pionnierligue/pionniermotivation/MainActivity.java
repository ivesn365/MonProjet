package com.pionnierligue.pionniermotivation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Button suiv, prec;
    private List<String> mot = new ArrayList<>();
    private Button shareBtn;
    private int nbre1 = 0;
    private double nbre = 0;
    FileInputStream fileInputStream = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


      /*  mot.add("L’idée de l’avenir est plus féconde que l’avenir lui-même. Henri Bergson");
        mot.add("Le futur appartient à ceux qui croient à la beauté de leurs rêves. Eleanor Roosevelt");
        mot.add("Je ne crains pas demain, car j’ai vécu hier et j’adore aujourd’hui. William Allan White");
        mot.add("L’homme se transporte dans l’avenir parce qu’il n’est jamais content du présent. Edward Young");
        mot.add("Apprendre pour améliorer l’avenir");
        mot.add("Ne revivez le passé que si vous allez vous en servir pour construire l’avenir.");
        mot.add("Vis le moment présent avec les leçons de ton passé et les rêves de ton futur. Paulo Coehlo");
        mot.add("Seuls ceux qui ont la mémoire longue sont capables de penser l’avenir. Friedrich Nietzsche");
        mot.add("Pour préparation sagement l’avenir, il est nécessaire de comprendre et d’apprécier le passé. Jo Coudert");
        mot.add("Saisissez-vous du présent, vous dépendrez moins de l’avenir. Sénèque");
        mot.add("On dépend de l’avenir quand on ne tire aucun parti du présent. Sénèque");
        mot.add("Vivre gagnant, c’est envisager l’avenir avec la certitude du succès. Jean-François Jacob");
        mot.add("Que l’avenir ne soit plus ce qui va arriver, mais ce que nous allons en faire. Henri Bergson");
        mot.add("De bonnes choses sont à venir sur ta route, n’arrête surtout pas de marcher ! Robert Warren");
        mot.add("L’avenir appartient aux audacieux, il appartient à ceux qui cherchent, qui prennent des risques.");
        mot.add("Le temps de parler du présent, il est déjà passé. Mais le futur, lui est modifiable. Philippe de Berny");
        mot.add("Ne regarde pas derrière toi en te demandant pourquoi. Regardes en avant et dis-toi pourquoi pas.");
        mot.add("Aujourd’hui, je choisis de dépasser mes limites du passé. Je suis prêt à m’adapter et à m’ouvrir à ce que le futur me réserve.");
        mot.add("Le moyen pour rester jeune est de sentir et d’agir toujours dans le présent, en dirigeant son regard vers l’avenir. Wu-Tig-Fang");
        mot.add("Il suffit d’un moment pour décider de tout un avenir. Pierre-Simon Ballanche");
        mot.add("Ton avenir est créé par ce que tu fais aujourd’hui, pas demain. Robert T. Kiyosaki");
        mot.add("Ce que vous êtes est ce que vous avez été. Ce que vous serez est ce que vous faites maintenant.");
        mot.add("Demandez-vous si ce que vous faites aujourd’hui vous rapproche de qui vous voulez être demain.");
        mot.add("La folie, c’est se comporter de la même manière et s’attendre à un résultat différent. Albert Einstein");
        mot.add("Votre avenir dépend des décisions d’un grand nombre de personnes, mais principalement des vôtres.");
        mot.add("En sachant seulement quel est l’idéal d’un homme, on peut prédire son avenir. Omraam Mikhaël Aïvanhov");
        mot.add("Pense que maintenant, à cet instant, tu es en train de créer… en train de créer ton propre avenir. Sara Paddison");
        mot.add("Il est sage de faire preuve de prévoyance quant à l’avenir, mais non pas de le craindre.");*/


        this.suiv = (Button) findViewById(R.id.suiv1);
        this.textView = (TextView) findViewById(R.id.motivation_mot);
        this.shareBtn = (Button) findViewById(R.id.share_btn);
        this.prec = (Button) findViewById(R.id.prec1);


        suiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nbre = Math.random() * 10;
               int nbree = (int)nbre;
                textView.setText(lectureFichier(nbree));
                // demarer une action "Intent" de partager les mots
                shareBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        intent.putExtra(Intent.EXTRA_TEXT, m(nbre1) + "label independant, pionnierligue.com");
                        startActivity(intent);
                    }
                });





            }
        });

        prec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nbre = Math.random() * mot.size();
                nbre1 = (int)nbre;
                textView.setText(m(nbre1));
                // demarer une action "Intent" de partager les mots
                shareBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        intent.putExtra(Intent.EXTRA_TEXT, mot.get(nbre1) + "pionnierligue.com, label v1.0");
                        startActivity(intent);
                    }
                });





            }

        });
    }

    public String m(int i) {
        //List<String> maListe = lectureFichier();
        return "" + mot.get(i) + "";
    }

    public String lectureFichier(int i) {
        try {
            fileInputStream = openFileInput("@asset/test.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;

            while ((line = bufferedReader.readLine()) != null) mot.add(line + "\n");


        } catch (FileNotFoundException e){ e.printStackTrace();
        }catch (IOException e){ e.printStackTrace();
        } finally {
            if (fileInputStream != null){
                try {
                    fileInputStream.close();
                } catch (IOException e){ e.printStackTrace();}
            }
        }
        return mot.get(i);
    }
}