package com.pionnierligue.pionniermotivation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LectureFichier {
    List<String> mot = new ArrayList<>();
   public LectureFichier(){
        try{
           File monfichier = new File("test.txt");
           // création de l'objet de lecture

            FileReader fileReader = new FileReader(monfichier);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String sb;

            while ((sb = bufferedReader.readLine()) != null) {
                mot.add(sb);
                //mot.add("\n");

            }
                fileReader.close();




        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String toString(int nbre1){
        return "" + mot.get(nbre1) + "";
    }
}
