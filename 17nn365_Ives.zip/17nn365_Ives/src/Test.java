
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Test {
	

	public static void main(String[] args) {

        // INTERFACE GRAPHIQUE
        JFrame fen=new JFrame("");
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setLocationRelativeTo(null);
        
        JPanel fond = new JPanel(new BorderLayout());
        GridLayout gd2 = new GridLayout(2,2);
        fond.setLayout(gd2);
        
        //PANE OPTION
        GridLayout layP=new GridLayout(0, 2);
        
        
        JButton btnAnnuler =new JButton("Annuler");
        JButton btnEnrF =new JButton("Enregistrer");
        
        JLabel lblDesign = new JLabel("Designation");
        JTextField txtDesign =new JTextField();
        JLabel lblPrix =new JLabel("Prix");
        JTextField txtPrix = new JTextField();
        JLabel lblStock =new JLabel("Stock");
        JTextField txtStock = new JTextField();
        JPanel panPrincipale=new JPanel();
        panPrincipale.setLayout(layP);
        panPrincipale.add(lblDesign);
        panPrincipale.add(txtDesign);
        panPrincipale.add(lblPrix);
        panPrincipale.add(txtPrix);
        panPrincipale.add(lblStock);
        panPrincipale.add(txtStock);
        //_________________Ajouter cours______________
        JLabel lblNomF = new JLabel("Nom Fournisseur");
        JTextField txtFieldNomF = new JTextField();
        JLabel lblPrenomF = new JLabel("Prenom ");
        JTextField txtFieldPrenomF = new JTextField();
        
        JButton annulerAjoutCours = new JButton("Annuler");
        JButton btnF = new JButton("Sauvegarder");
        JPanel panF = new JPanel();
        panF.setLayout(layP);
        panF.add(lblNomF);
        panF.add(txtFieldNomF);
        panF.add(lblPrenomF);
        panF.add(txtFieldPrenomF);
    
        panF.add(new JLabel());
        
        JPanel panButtons = new JPanel();
        
        panButtons.add(annulerAjoutCours);
        panButtons.add(btnF);
        panF.add(panButtons);
        panF.setVisible(false);
        
        //________________Resultat a afficher_______
       
        //Container contAfficheRes = Box.createVerticalBox();
        
        JButton retour = new JButton("Retour");
        JButton validerAffichage = new JButton("Valider");
        
        JPanel panButtonAffiche = new JPanel();
        JPanel contAfficheRes = new JPanel(new BorderLayout());
        contAfficheRes.setVisible(false);
        JPanel contAjout = new JPanel(new BorderLayout());
        contAjout.setVisible(false);
        
        panButtonAffiche.add(retour);
        panButtonAffiche.add(validerAffichage);        
        
        JPanel p2=new JPanel();
        p2.add(btnAnnuler);
        p2.add(btnEnrF);
        
        panPrincipale.add(new JLabel());
        panPrincipale.add(p2);
        panPrincipale.setVisible(false);
        
        JMenuBar barMenu=new JMenuBar();
        JMenu menuFichier=new JMenu("Fichier");
        JMenu menuEdition=new JMenu("Vente");
        
        JMenuItem itA = new JMenuItem("Ajouter article");
        
        JMenuItem it1 = new JMenuItem("Ajouter fournisseur");
        JMenuItem it2 = new JMenuItem("Ajouter article");
        JMenuItem it3 = new JMenuItem("Afficher fournisseur");
        JMenuItem it4 = new JMenuItem("Afficher article");
        
        menuFichier.add(it1);
        menuFichier.add(it2);
        menuFichier.add(it3);
        menuFichier.add(it4);
        
        //LES EVENEMENTS
        it1.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                fond.add(panF, 0);
                panF.setVisible(true);
            }
            
        });
        it2.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                fond.add(panPrincipale,0);
                panPrincipale.setVisible(true);
            }
            
        });
        it3.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                //System.out.println("Bonjour le monde !");
            	Fournisseur f = new Fournisseur();
            	String l = "";
            	for(int i = 0; i < f.afficherFournisseur().size(); i++) l += f.afficherFournisseur().get(i) + '\n';
            	contAfficheRes.add(new JTextArea(l));
                fond.add(contAfficheRes, 0);
                contAfficheRes.setVisible(true);
            }
            
        });
        it4.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                //System.out.println("Bonjour le monde !");
            	Article f = new Article();
            	String l = "";
            	for(int i = 0; i < f.afficher().size(); i++) l += f.afficher().get(i) + '\n';
            	contAfficheRes.add(new JTextArea(l));
                fond.add(contAfficheRes, 0);
                contAfficheRes.setVisible(true);
            }
            
        });
        itA.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                //System.out.println("Bonjour le monde !");
            	Article f = new Article();
            	String l = "";
            	for(int i = 0; i < f.afficher().size(); i++) l += f.afficher().get(i) + '\n';
            	contAfficheRes.add(new JTextArea(l));
                fond.add(contAfficheRes, 0);
                contAfficheRes.setVisible(true);
            }
            
        });
        btnEnrF.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
            	Article f = new Article(txtDesign.getText(), Integer.valueOf(txtPrix.getText()), Integer.valueOf(txtStock.getText()));
				try {
					f.write();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
            }
            
        });
        btnAnnuler.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("Bonjour ");
                panPrincipale.setVisible(false); 
                fond.remove(panPrincipale);      
            }
            
        });
        btnF.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
            	Fournisseur f = new Fournisseur(txtFieldNomF.getText(), txtFieldPrenomF.getText());
				try {
					f.ajouterFournisseur();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
            
        });
        annulerAjoutCours.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                panF.setVisible(false);
                fond.removeAll();
            }
            
        });
        retour.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                contAfficheRes.setVisible(false);
//                contAfficheRes.removeAll();
                fond.removeAll();
            }
            
        });
        validerAffichage.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                contAfficheRes.setVisible(false);
//                contAfficheRes.removeAll();
                fond.removeAll();
            }
            
        });
        
        barMenu.add(menuFichier);
        barMenu.add(menuEdition);
        
        fen.setContentPane(fond);
        fen.setJMenuBar(barMenu);
        fen.setSize(700, 500);
//        fen.pack();
        fen.setVisible(true);

	}
}