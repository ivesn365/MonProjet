
	import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Fen {
	public static void main(String[] args) {
		JFrame fen=new JFrame("");
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setLocationRelativeTo(null);
        JPanel conteneur = new JPanel(new BorderLayout());
      
        JMenuBar barMenu=new JMenuBar();
        JMenu menuFichier=new JMenu("L'approvisionnement");
        JMenu menuEdition=new JMenu("Vente");
        
        JMenuItem ajouterFournisseur = new JMenuItem("ajouterFournisseur");
       
        JMenuItem ajouterArticle = new JMenuItem("ajouterArticle");
        menuFichier.add(ajouterFournisseur);
        menuFichier.add(ajouterArticle);
       
       
       
        JPanel four = fournisseur();
        JPanel article = article();
        
        ajouterFournisseur.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stu
				System.out.println("Bonjour le monde !");
				conteneur.add(four, 0);
				four.setVisible(true);
				article.setVisible(false);
				conteneur.remove(article);
		        
				
			}
		});
        
        ajouterArticle.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stu
				JPanel j = new JPanel(new BorderLayout());
		        
				j.setVisible(true);
		        article().setVisible(false);
		        conteneur.add(j, BorderLayout.NORTH);
				conteneur.remove(article());
				
		        
				
			}
		});
        
        
      
        
        conteneur.add(fournisseur());
        conteneur.add(article());
       
        
        
        barMenu.add(menuFichier);
        barMenu.add(menuEdition);
        
       
        fen.setContentPane(conteneur);
        
        fen.setJMenuBar(barMenu);
       // fen.setSize(400, 200);
       fen.pack();
        fen.setVisible(true);

	}
	
	public static JPanel fournisseur() {
	     
		  JLabel nomfourn = new JLabel("nom Fournisseur");
	        JLabel prenomFour = new JLabel();
	        prenomFour.setText("Prenom Fournisseur");
	        
	        JTextField txtNom = new JTextField();
	        JTextField txtPrenom = new JTextField();
        
	        JButton btnAnnuler = new JButton("Annuler");
	        JButton btnEnr = new JButton("Enregistrer");
        
        JPanel panPrincipale1=new JPanel();
        GridLayout layP=new GridLayout(0, 2);
        panPrincipale1.setLayout(layP);
        panPrincipale1.add(nomfourn);
        panPrincipale1.add(txtNom);
        panPrincipale1.add(prenomFour);
        panPrincipale1.add(txtPrenom);
        
        btnEnr.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				Fournisseur f = new Fournisseur(txtNom.getText(), txtPrenom.getText());
				try {
					f.ajouterFournisseur();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
        
        JPanel p2=new JPanel();
        p2.add(btnAnnuler);
        p2.add(btnEnr);
        
        panPrincipale1.add(new JLabel());
        panPrincipale1.add(p2);
      
        return panPrincipale;
	}
	
	public static JPanel article() {
	     
		JLabel design = new JLabel("Designation");
		
        JLabel Stock = new JLabel("Stock");
        JLabel prix = new JLabel("Prix");
        
        
        JTextField txtDesign = new JTextField();
        JTextField txtPrix = new JTextField();
        JTextField txtStock = new JTextField();
      
	    JButton btnAnnuler = new JButton("Annuler");
	    JButton btnEnr = new JButton("Enregistrer");
      
      JPanel panPrincipale=new JPanel();
      GridLayout layP=new GridLayout(0, 2);
      panPrincipale.setLayout(layP);
      panPrincipale.add(design);
      panPrincipale.add(txtDesign);
      panPrincipale.add(prix);
      panPrincipale.add(txtPrix);
      panPrincipale.add(Stock);
      panPrincipale.add(txtStock);
      
      btnEnr.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				Article f = new Article(txtDesign.getText(), Integer.valueOf(txtPrix.getText()), Integer.valueOf(txtStock.getText()));
				try {
					f.write();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
      
      JPanel p2=new JPanel();
      p2.add(btnAnnuler);
      p2.add(btnEnr);
      
      panPrincipale.add(new JLabel());
      panPrincipale.add(p2);
    
      return panPrincipale;
	}
}
