import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Fournisseur {
	private String nom;
	private String prenom;
	public Fournisseur() {}
	public Fournisseur(String nom, String prenom) {
		super();
		this.nom = nom;
		this.prenom = prenom;
	}
	
	
	public void ajouterFournisseur() throws IOException {
		// TODO Auto-generated method stub
		File  monDossier = new File("gestionCotes");
		if(monDossier.isDirectory()) {
			monDossier.mkdir();
			
		}
		FileWriter monFichier = new FileWriter("fournisseur.txt", true);
			
				//monFichier.createNewFile();
				PrintWriter p = new PrintWriter(monFichier);
				p.println(toString());
				p.flush();
		
	}
	
	public List<String> afficherFournisseur() {
		List<String> f = new ArrayList<String>();
		try {
			BufferedReader read = new BufferedReader(new FileReader("fournisseur.txt"));
			String ligne;
			while((ligne = read.readLine()) != null) {
				f.add(ligne);
				
			}
			read.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return f;
	}
	
	


	@Override
	public String toString() {
		return "Fournisseur [nom=" + nom + ", prenom=" + prenom + "]";
	}
	

}
