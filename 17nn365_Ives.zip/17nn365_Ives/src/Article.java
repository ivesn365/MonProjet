import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Article {
	private String design;
	private int prix;
	private int stock;
	public Article() {}
	public Article(String design, int prix, int stock) {
		super();
		this.design = design;
		this.prix = prix;
		this.stock = stock;
	}
	public void write() throws IOException {
		// TODO Auto-generated method stub
		File  monDossier = new File("gestionCotes");
		if(monDossier.isDirectory()) {
			monDossier.mkdir();
			
		}
		FileWriter monFichier = new FileWriter("article.txt", true);
			
				//monFichier.createNewFile();
				PrintWriter p = new PrintWriter(monFichier);
				p.println(toString());
				p.flush();
		
	}
	
	public List<String> afficher() {
		List<String> f = new ArrayList<String>();
		try {
			BufferedReader read = new BufferedReader(new FileReader("article.txt"));
			String ligne;
			while((ligne = read.readLine()) != null) {
				f.add(ligne);
				
			}
			read.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return f;
	}
	@Override
	public String toString() {
		return "Article [design=" + design + ", prix=" + prix + ", stock=" + stock + "]";
	}
	
	

}
