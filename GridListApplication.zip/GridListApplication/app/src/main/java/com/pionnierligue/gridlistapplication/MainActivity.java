package com.pionnierligue.gridlistapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ViewStub stubGrid;
    private ViewStub stubList;
    private ListView listView;
    private GridView gridView;
    private ListViewAdapter listViewAdapter;
    private GridViewAdapter gridViewAdapter;
    private List<Product> productList;
    private int currentView = 0;

    static final int VIEW_MODE_LISTVIEW = 0;
    static final int VIEW_MODE_GRIDVIEW = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stubList = findViewById(R.id.stub_list);
        stubGrid = findViewById(R.id.stub_grid);

        // inflate ViewStub before get VIew

        stubList.inflate();
        stubGrid.inflate();

        listView = findViewById(R.id.myListView);
        gridView = findViewById(R.id.myGridList);

        // get List product

        getProductList();

        //get current view mode in share reference

        SharedPreferences sharedPreferences = getSharedPreferences("ViewMode", MODE_PRIVATE);
        currentView = sharedPreferences.getInt("currentViewMode", VIEW_MODE_LISTVIEW);// default is view listview

        // Register item
        listView.setOnItemClickListener(onItemClickListener);
        gridView.setOnItemClickListener(onItemClickListener);
        switchView();
    }

    private void switchView() {
        if (VIEW_MODE_LISTVIEW == currentView){
            // Display listview
            stubList.setVisibility(View.VISIBLE);
            // Display GridView
            stubGrid.setVisibility(View.GONE);
        } else{
            stubList.setVisibility(View.GONE);
            stubGrid.setVisibility(View.VISIBLE);
        }
        setAdapters();
    }

    private void setAdapters() {
        if (VIEW_MODE_LISTVIEW == currentView){
            listViewAdapter = new ListViewAdapter(this, R.layout.list_item, productList);
            listView.setAdapter(listViewAdapter);
        }else {
            gridViewAdapter = new GridViewAdapter(this, R.layout.grid_item, productList);
            gridView.setAdapter(gridViewAdapter);
        }
    }

    private List<Product> getProductList() {
        // pseudo code to get product, replace your code to get real product here

        productList = new ArrayList<>();
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));
        productList.add(new Product("cookie", "title 1", "this is description"));


        return productList;
    }
    AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            // Do my when user click to item
            Toast.makeText(getApplicationContext(), productList.get(i).getTitle() + " - " + productList.get(i).getDesc(), Toast.LENGTH_SHORT).show();
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item_menu_1:
                if (VIEW_MODE_LISTVIEW == currentView){
                    currentView = VIEW_MODE_GRIDVIEW;
                }else{
                    currentView = VIEW_MODE_LISTVIEW;
                }
                //SwitchView
                switchView ();
                // save view mode is share reference
                SharedPreferences sharedPreferences = getSharedPreferences("viewMode", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("currentViewMode", currentView);
                editor.commit();
                break;
        }
        return true;
    }
}