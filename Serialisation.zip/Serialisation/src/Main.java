import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Enseignant();
		p.setAdress("5 av, femme Katangaise c/Lubumbashi");
		p.setNom("Ndaya");
		p.setPrenom("Immaculée");
		p.setTelephone("+243 254 879 54");
		
		try {
			FileOutputStream fileOut = new FileOutputStream("ensegnant.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(p);
			out.close();
			fileOut.close();
		}catch(IOException e) {
			e.printStackTrace();
		}

	}

}
