import java.io.Serializable;

public class Person implements Serializable{
	private String nom;
	private String postnom;
	private String prenom;
	private String adress;
	private String telephone;
	
	
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Person(String newNom, String newPostnom, String newPrenom, String newadress, String newTelephone) {
		super();
		this.nom = newNom;
		this.postnom = newPostnom;
		this.prenom = newPrenom;
		this.adress = newadress;
		this.telephone = newTelephone;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String newNom) {
		this.nom = newNom;
	}


	public String getPostnom() {
		return postnom;
	}


	public void setPostnom(String newPostnom) {
		this.postnom = newPostnom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String newPrenom) {
		this.prenom = newPrenom;
	}


	public String getAdress() {
		return adress;
	}


	public void setAdress(String newadress) {
		this.adress = newadress;
	}


	public String getTelephone() {
		return telephone;
	}


	public void setTelephone(String newTelephone) {
		this.telephone = newTelephone;
	}


	@Override
	public String toString() {
		return "Person [nom=" + nom + ", postnom=" + postnom + ", prenom=" + prenom + ", adress=" + adress
				+ ", telephone=" + telephone + "]";
	}
	
	
	

}
