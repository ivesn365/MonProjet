
public class Enseignant extends Person {
	private String matricule;
	private double salaire;
	public Enseignant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Enseignant(String newNom, String newPostnom, String newPrenom, String newadress, String newTelephone, String newMatricule, double newSalaire) {
		super(newNom, newPostnom, newPrenom, newadress, newTelephone);
		// TODO Auto-generated constructor stub
		this.matricule = newMatricule;
		this.salaire = newSalaire;
	}
	public String getMatricule() {
		return matricule;
	}
	public void setMatricule(String newMatricule) {
		this.matricule = newMatricule;
	}
	public double getSalaire() {
		return salaire;
	}
	public void setSalaire(double newSalaire) {
		this.salaire = newSalaire;
	}
	@Override
	public String toString() {
		return "Enseignant [matricule=" + matricule + ", salaire=" + salaire + "]";
	}
	
	
	
	

}
