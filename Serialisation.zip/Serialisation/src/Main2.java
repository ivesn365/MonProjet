import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person person = new Person();
		try {
			FileInputStream fileIn = new FileInputStream("ensegnant.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			person = (Enseignant) in.readObject();
			in.close();
			fileIn.close();
		}catch(IOException i) {
			i.printStackTrace();
			return;
	
		
	   }catch(ClassNotFoundException e) {
		   System.out.print("Classe enseignant no trouvée ! ! !");
		   e.printStackTrace();
	   }
		System.out.println("============================= Deserialized enseignant ========================");
		System.out.println("Nom : " + person.getNom());
		System.out.println("Prénom : " + person.getPrenom());
		System.out.println("adresse : " + person.getAdress());
		System.out.println("Téléphone : " + person.getTelephone());

	}

}
