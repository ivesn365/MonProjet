package com.ives.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int nbreCache  = 50;
    ImageView imageView;
    EditText editText;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.imgAffichage);
        editText = (EditText) findViewById(R.id.editNbre);
        button = (Button) findViewById(R.id.cmdDevinez);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(nbreCache  >  Integer.parseInt(editText.getText().toString())){
                    Toast.makeText(MainActivity.this, "Augmentez ! !", Toast.LENGTH_LONG).show();
                    imageView.setImageResource(R.drawable.goup);
                }else if(nbreCache  < Integer.parseInt(editText.getText().toString())){
                    Toast.makeText(MainActivity.this, "Dimunuez !", Toast.LENGTH_LONG).show();
                    imageView.setImageResource(R.drawable.godown);
                }else{
                    Toast.makeText(MainActivity.this, "Bravo ! ! You are so magic !", Toast.LENGTH_LONG).show();
                    imageView.setImageResource(R.drawable.youwin);

                }
            }
        });
    }
}